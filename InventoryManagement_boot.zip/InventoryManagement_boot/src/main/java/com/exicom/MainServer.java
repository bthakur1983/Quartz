package com.exicom;

import java.rmi.RemoteException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.ServletContextAware;

import com.exicom.dao.IssueProductsImplement;
import com.exicom.dao.UserDao;
import com.exicom.dao.UserDaoImplment;
import com.exicom.model.IssueProducts;
import com.exicom.model.User;
import com.exicom.util.HibernateUtil;

@Controller
public class MainServer extends HttpServlet 
{
	  
	@Autowired
    private SessionFactory sessionFactory;
	
	public void init()throws ServletException
	{
 	
 		//loadUsers();
//		loadIssueProductIntoCheckerList();
		
		
		
		 
	}
	
	public boolean loadUsers()
	{
		
		String sqlQuery = "select n from com.exicom.Model.User n where n.username='admin'";
		boolean result = false;
		try {
			 
			List<User>list = sessionFactory.getCurrentSession().createSQLQuery(sqlQuery).list();
			if(list.size()>0)
			{
				
			}
			else
			{
				User user  = new User();
				user.setUsername("admin");
				user.setPassword("admin");
				 Calendar calender = Calendar.getInstance(); 
				 calender.setTime(new Date());
				 user.setNeName(calender.getTimeInMillis());
				 
				 result = new UserDaoImplment().register(user);
				 if(result)
					 System.out.println("default user updated....");
				 else
					 
					 System.out.println("default user Not updated");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
		
	}

	public void loadIssueProductIntoCheckerList()
	{
		try {
			List<IssueProducts>list = new IssueProductsImplement().getIssueProducts();
			if(list.size()>0)
			{
				for(int i=0;i<list.size();i++)
				{
					IssueProducts prod = list.get(i);
					//SmartChecker.getIstance().addNewIssueObject(""+prod.getNeName(), prod);
					
				}
				
			}
		}
		catch(Exception e)
		{
			
		}
	}
	 
}
