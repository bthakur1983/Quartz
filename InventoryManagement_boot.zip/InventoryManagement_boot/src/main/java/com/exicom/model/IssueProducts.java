package com.exicom.model;


import java.util.Date;


import javax.persistence.Cacheable;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@Table
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)
public class IssueProducts 
{
	@Id
	private long neName;

	private String empName;

	private String empCode;
	
	@Size(min=10,max=10,message="Size.userform.empMobile")
	private String empMobile;
	
	private Date issueDate;
 
 	private String prodName;
 	
 	private String prodModelNo;
 	
 	private String remaningQnt;
 	
 	private Date returnItemDate;
	
 	private String status;
	
	
  
	 

	public long getNeName() {
		return neName;
	}
	public void setNeName(long neName) {
		this.neName = neName;
	}

	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getEmpMobile() {
		return empMobile;
	}
	public void setEmpMobile(String empMobile) {
		this.empMobile = empMobile;
	}
	
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	

	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdModelNo() {
		return prodModelNo;
	}
	public void setProdModelNo(String prodModelNo) {
		this.prodModelNo = prodModelNo;
	}

	public String getRemaningQnt() {
		return remaningQnt;
	}
	public void setRemaningQnt(String remaningQnt) {
		this.remaningQnt = remaningQnt;
	}
	
	public Date getReturnItemDate() {
		return returnItemDate;
	}
	public void setReturnItemDate(Date returnItemDate) {
		this.returnItemDate = returnItemDate;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
 
	
	

}
