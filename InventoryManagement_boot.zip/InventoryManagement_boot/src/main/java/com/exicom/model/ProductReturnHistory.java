package com.exicom.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class ProductReturnHistory 
{
	@Id
	private long neName; 
	private String prodName;
	private String prodAcceptBy;
	private String prodModel;
	private String emplName;
	private String emplCode;
	private Date issueDate;		
	private Date returnDate;
	
	@Column(name="neName")
	public long getNeName() {
		return neName;
	}
	public void setNeName(long neName) {
		this.neName = neName;
	}
	@Column(name="prodName")
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	@Column(name="empName")
	public String getEmplName() {
		return emplName;
	}
	public void setEmplName(String emplName) {
		this.emplName = emplName;
	}
	@Column(name="empCode")
	public String getEmplCode() {
		return emplCode;
	}
	public void setEmplCode(String emplCode) {
		this.emplCode = emplCode;
	}
	@Column(name="issueDate")
	public Date getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}
	@Column(name="returnDate")
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	@Column(name="ProdModel")
	public String getProdModel() {
		return prodModel;
	}
	public void setProdModel(String prodModel) {
		this.prodModel = prodModel;
	}
	@Column(name="ProdAcceptBy")
	public String getProdAcceptBy() {
		return prodAcceptBy;
	}
	public void setProdAcceptBy(String prodAcceptBy) {
		this.prodAcceptBy = prodAcceptBy;
	}
	
	
	
	

}
