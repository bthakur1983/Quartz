package com.exicom.model;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table
public class Product 
{
	@Id
	private String prod_Name;
	private String prod_SrNo;
	private String model_No;
	private String prod_Quantity;
	private String remaning_Quantity;
 
	 
	public String getProd_Name() {
		return prod_Name;
	}
	public void setProd_Name(String prod_Name) {
		this.prod_Name = prod_Name;
	}
	 
	public String getProd_SrNo() {
		return prod_SrNo;
	}
	public void setProd_SrNo(String prod_SrNo) {
		this.prod_SrNo = prod_SrNo;
	}
	public String getModel_No() {
		return model_No;
	}
	public void setModel_No(String model_No) {
		this.model_No = model_No;
	}
	public String getProd_Quantity() {
		return prod_Quantity;
	}
	public void setProd_Quantity(String prod_Quantity) {
		this.prod_Quantity = prod_Quantity;
	}
	public String getRemaning_Quantity() {
		return remaning_Quantity;
	}
	public void setRemaning_Quantity(String remaning_Quantity) {
		this.remaning_Quantity = remaning_Quantity;
	}
	 
	

}
