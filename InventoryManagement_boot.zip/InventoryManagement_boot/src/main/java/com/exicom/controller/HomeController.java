package com.exicom.controller;
 

import org.jboss.logging.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.io.IOException;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.servlet.ModelAndView;

import org.springframework.web.bind.annotation.SessionAttribute;

import com.exicom.SmartChecker;
import com.exicom.dao.AddProductDao;
import com.exicom.dao.CanvasChartDao;
import com.exicom.dao.IssueProductDao;
import com.exicom.dao.IssueProductsImplement;
import com.exicom.dao.ReturnProductHistoryDao;
import com.exicom.dao.UserDao;
import com.exicom.dao.UserDaoImplment;
import com.exicom.model.IssueProducts;
import com.exicom.model.Product;
import com.exicom.model.ProductReturnHistory;
import com.exicom.model.User;
import com.exicom.util.ComponentConstantStrings;
import com.exicom.util.WrapperLists;
 
 
@Controller
@SessionAttributes("user")
public class HomeController implements ServletContextAware {
	
	private static final Logger logger = Logger.getLogger(HomeController.class);
	
	public HomeController() {
		System.out.println("HomeController called........");
	}

	@Autowired
	ServletContext context;
    @Autowired
    private UserDao userDaoService;
    @Autowired
    private AddProductDao addProdService;
    @Autowired
    private IssueProductDao issueProdService;
    @Autowired
    private CanvasChartDao canvasChartService;
    @Autowired
    private ReturnProductHistoryDao returnProdService;
    
    //private EmployeeService employeeService;

    SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	private int faultyUser = 0;
	private String userName=null;
	public boolean isDuplicate = false;
	
	 @ModelAttribute("user")
	 public User setUpUserForm() 
	 {
	      return new User();
	     
	 }
	 
	public void loadIssueProductIntoCheckerList()
	{
		try {
			List<IssueProducts>list = issueProdService.getIssueProducts();
			if(list.size()>0)
			{
				for(int i=0;i<list.size();i++)
				{
					IssueProducts prod = list.get(i);
					SmartChecker.getIstance(issueProdService).addNewIssueObject(""+prod.getNeName(), prod);
					
				}
				
			}
		}
		catch(Exception e)
		{
			
		}
	}
	
    @RequestMapping("/")
	public String home()
	{
    	 String sqlQuery = "select n from com.exicom.model.User n where n.username = 'admin'";
 		//String sqlQuery = "SELECT e.* FROM User e WHERE e.username like 'admin'";
    	 
		try {
			 List<User>list = userDaoService.getDataFromDB(sqlQuery);
			 if(list == null || list.size() <= 0)
	    	 {
	    		 
				User user  = new User();
				user.setUsername("admin");
				user.setPassword("admin");
				user.setEmpName("admin");
				user.setEmpRole(ComponentConstantStrings.ADMIN_ROLE);
				user.setEmpMobile("9999999999");
				 Calendar calender = Calendar.getInstance(); 
				 calender.setTime(new Date());
				 user.setNeName(calender.getTimeInMillis());
				 
				 boolean result = userDaoService.register(user);
				 if(result)
					 System.out.println("default user updated....");
				 else					 
					 System.out.println("default user Not created in DB");
	    	 }
			 loadIssueProductIntoCheckerList();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	 
		 context.setAttribute("faultyUser", faultyUser);
		 return "login.jsp";
	}
    
    
    @RequestMapping(value = {"/callUserRegistration"}, method = RequestMethod.GET)
	 public ModelAndView callUserRegistration(@SessionAttribute("user") User user) 
	 {
    	
   	 ModelAndView mav  = new ModelAndView("UserRegistration.jsp");
   	 context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
    
   	 return mav;
	 }
    
     @RequestMapping(value = {"/callChangePwd"}, method = RequestMethod.GET)
	 public ModelAndView callChangePwd(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
	 {
    	
	     List<User>userList = userDaoService.getUsers(); 
	     WrapperLists wrapperList= null;
	     if(userList != null)
		 {
	    	 wrapperList = new WrapperLists();
	    	 wrapperList.setUserList(userList);
		 }
	     
	  	 ModelAndView mav  = new ModelAndView("ChangePwd.jsp");
	  	 mav.addObject("userslist",wrapperList);
	  	 context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
	   
	  	 return mav;
	 }
     
     @RequestMapping(value = {"/submitChangePwd"}, method = RequestMethod.POST)
	 public ModelAndView submitChangePwd(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
	 {
    	User userObj = new User();
    	ModelAndView mav  = new ModelAndView("ChangePwd.jsp");
    	String userName = request.getParameter("username");
    	String oldPwd = request.getParameter("oldPwd");
    	String newPwd = request.getParameter("password");
    	String retypePwd = request.getParameter("reEnterPwd");
    	String sqlQuery = "select n from com.exicom.model.User n where n.username = '"+userName+"'";
    	try
    	{
    	List<User>list = userDaoService.getDataFromDB(sqlQuery);
    	context.setAttribute("roleName", list.get(0).getEmpRole().toString());
    	if(!newPwd.equals(retypePwd))
    	{
    		mav.addObject("message","New Password and Re-Password Mismatch !"); 
    	}
    	else
    	{
	    	 
	    	 
			 if(list.size() > 0)
			 {
				 
				 if(list.get(0).getPassword().equals(oldPwd))
				 {
					 userObj = (User)list.get(0);
					 userObj.setPassword(newPwd);
					 if(userDaoService.register(userObj))
						 mav.addObject("message","Password Update Sucessfully !"); 
					 else
						 mav.addObject("message","Password Have Not Saved Contect to Admin..!"); 
				 }
				 else
				 {
					 mav.addObject("message","Old Password is Not Correct!"); 
				 }
			 }
			 else
			 {
				 mav.addObject("message","Password Have Not Saved Contect to Admin..!"); 
			 }
    	}
    	}
    	catch(Exception e)
    	{
    		
    	}
    	
    	
  	  
  	 context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
  	 List<User>userList = userDaoService.getUsers(); 
  	 WrapperLists wrapperList= null;
  	 if(userList != null)
	 {
   	 wrapperList = new WrapperLists();
   	 wrapperList.setUserList(userList);
	 }
  	 mav.addObject("userslist",wrapperList);
  	
  	 return mav;
	 }
    
     @RequestMapping(value = {"/createUser"}, method = RequestMethod.POST)
	 public ModelAndView createUser(@ModelAttribute("user")User user) 
	 {
    	 isDuplicate = false;
    	 ModelAndView mav = new ModelAndView("UserRegistration.jsp");
    	 
    	 List<User> userList = userDaoService.getUsers();
    	 
    	 userList.stream().filter(userData->userData.getPassword().trim().equals(user.getPassword().trim())).forEach(val->{
    		 System.out.println(val.getUsername());
    		 isDuplicate = true;
    	 });
    	
    	 if(isDuplicate)
    	 {
    		 mav.addObject("message","User or Password Already Created !");
    		 return mav;
    	 }  	 
    	 Calendar calender = Calendar.getInstance(); 
		 calender.setTime(new Date());
		 user.setNeName(calender.getTimeInMillis());	 
		 boolean result = userDaoService.register(user);
		 if(result)
		 {
			 
			 mav.addObject("message","User Create Sucessfully !");
		 }
		 else
		 {
			 mav.addObject("message","Account Does Not Create Try Again ! !");
		 }
    	
    	 return mav;
	 }
     
	 @RequestMapping(value = {"/loginProcess"}, method = RequestMethod.POST)
	 public ModelAndView loginProcess(@ModelAttribute("user")User user) 
	 {
		 faultyUser = 0;
		 ModelAndView mav  = null;
		 WrapperLists wrapperList = null;
  		 String sqlQuery = "select n from com.exicom.model.User n where n.username='"+user.getUsername()+"' and n.password='"+user.getPassword()+"'";
  		 
		try {
			List<User>list = userDaoService.getDataFromDB(sqlQuery);
			if(list != null && list.size() > 0)
			{
				  user.setUsername(user.getUsername());
				  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.FAULTY_STATUS+"'";
				  List<IssueProducts>faultyIssueList = issueProdService.getIssueProduct(query);
				  if(faultyIssueList.size()>0)
				  {
					 faultyUser = faultyIssueList.size();
				  }
 					 

				  
				 SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().put("faultyUser", faultyUser);
				 context.setAttribute("faultyUser", faultyUser);
				 context.setAttribute("roleName", list.get(0).getEmpRole().toString());
				  
				 
				 List<Product>totalProdList = addProdService.getProducts();
				 HashMap<String, String> map =new HashMap<>();
				 map.put("totalProd", ""+totalProdList.size());
				 try {
					 WebSocketController.updateDashBoard(map);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 
				 
				 List<List<Map<Object, Object>>> canvasjsDataList = canvasChartService.getCanvasjsChartData(totalProdList);
				 List<List<Map<Object, Object>>> canvasjsDataList2 = canvasChartService.getCanvasjsChartFaultyData(issueProdService.getIssueProducts());
				  wrapperList = new WrapperLists();
				  wrapperList.setList(faultyIssueList);
				  //wrapperList.setProdList(totalProdList);
				  mav = new ModelAndView("HomePage.jsp");
				  mav.addObject("issuelist",wrapperList);
				  mav.addObject("dataPointsList",canvasjsDataList);
				  mav.addObject("dataPointsList2",canvasjsDataList2);
				  userName = user.getUsername();
				  context.setAttribute("userName", userName);
			}
				
			 
			else
			{
				 mav = new ModelAndView("login.jsp");
				 mav.addObject("message","UserName or Password Mismatch try again !");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		 return mav;
	  }
	
	 @RequestMapping(value = {"/homePage"}, method = RequestMethod.GET) 
	 public ModelAndView homePage(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user)
	 {
		  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.FAULTY_STATUS+"'";
		  List<IssueProducts>faultyIssueList = issueProdService.getIssueProduct(query);
		  
		  List<Product>totalProdList = addProdService.getProducts();
		  context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
		  WrapperLists wrapperList = new WrapperLists();
		  wrapperList.setList(faultyIssueList);
		 List<List<Map<Object, Object>>> canvasjsDataList = canvasChartService.getCanvasjsChartData(totalProdList);
		 List<List<Map<Object, Object>>> canvasjsDataList2 = canvasChartService.getCanvasjsChartFaultyData(issueProdService.getIssueProducts());
		 ModelAndView mav = new ModelAndView("HomePage.jsp");
		 mav.addObject("issuelist",wrapperList);
		 mav.addObject("dataPointsList",canvasjsDataList);
		 mav.addObject("dataPointsList2",canvasjsDataList2);
		 HashMap<String, String> map =new HashMap<>();
		 map.put("totalProd", ""+totalProdList.size());
		 try {
			 WebSocketController.updateDashBoard(map);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 return mav;
	  }
	  @RequestMapping(value = "/addProduct", method = RequestMethod.GET)
	  public ModelAndView addProduct(@SessionAttribute("user") User user) 
	  {
 		  WrapperLists wrapperList = new WrapperLists();
		  ModelAndView mav = new ModelAndView("AddProd.jsp");
		  
			  List<Product>prodList = addProdService.getProducts();			 
			  wrapperList.setProdList(prodList);			  			  
			  mav.addObject("Product",new Product());
			  mav.addObject("prodItemList",wrapperList);
			  //mav.addObject("userName",user.getUsername());
			  context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
		   
		  return mav;
	  }

	  @RequestMapping(value = "/saveProduct", method = RequestMethod.POST)
	  public ModelAndView saveProduct(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("Product")Product product,@SessionAttribute("user") User user) 
	  {

		  boolean result = addProdService.register(product);
		  ModelAndView mav = new ModelAndView("AddProd.jsp");
		  WrapperLists wrapperList = new WrapperLists();
		  if(result)
		  {
				  mav.addObject("message","Product Saved Sucessfully");
				  List<Product>prodList = addProdService.getProducts();
				  wrapperList.setProdList(prodList);
		  }
		 else
		 {
			mav.addObject("message","Product is not saved plz do again !");
		 }
		  mav.addObject("Product",new Product());
		  mav.addObject("prodItemList",wrapperList);
		 // mav.addObject("userName",user.getUsername());
		  return mav;
	  }
	  
	
	 

	  @RequestMapping(value = "/issueProduct", method = RequestMethod.GET)
	  public ModelAndView issueProduct(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
	  {
		   
		  WrapperLists wrapperList = null;
		  IssueProducts issueProducts = null;
		  List<Product>prodList = null;
		  
		  ModelAndView mav = new ModelAndView("IssueProduct.jsp");
		  
		  prodList = addProdService.getProducts();
		  if(prodList.size()>0)
		  {
			  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.VALID_STATUS+"'";
			  List<IssueProducts>issueList = issueProdService.getIssueProduct(query);
			 
			  wrapperList = new WrapperLists();
			  wrapperList.setProdList(prodList);
			  WrapperLists  wrapperList2 = new WrapperLists();
			  wrapperList2.setList(issueList);
			  issueProducts = new IssueProducts();			  
			 // issueProducts.setProdModelNo(prodList.get(0).getModel_No());
			  mav.addObject("prodItemList",wrapperList);
			  mav.addObject("issueItemList",wrapperList2);
			  context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
			
		  }
		  else
		  {
			  mav = new ModelAndView("Warning.jsp");
			  mav.addObject("message","There is No Product Available in List, First Add Products. !");
		  }
		  return mav;
	  }
	 
	  @RequestMapping(value = "/submitIssueDetails", method = RequestMethod.POST)
	  public ModelAndView submitIssueDetails(@Valid @ModelAttribute("IssueProducts")IssueProducts issueProducts,BindingResult binResult,@SessionAttribute("user") User user) 
	  {
		  ModelAndView mav = new ModelAndView("IssueProduct.jsp");
		  if(binResult.hasErrors())
			  return mav;
		  WrapperLists wrapperList = null;
		  Calendar calender = Calendar.getInstance(); 
		  calender.setTime(new Date());
		  issueProducts.setNeName(calender.getTimeInMillis());
		  issueProducts.setStatus("valid");

	 	  boolean result = issueProdService.register(issueProducts);
 		 
		  if(result)
		  {
			  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.VALID_STATUS+"'";
			  List<IssueProducts>issueList = issueProdService.getIssueProduct(query);		   
			  SmartChecker.getIstance(issueProdService).addNewIssueObject(""+issueProducts.getNeName(), issueProducts);
			  Product prod = addProdService.getProducts(issueProducts.getProdName());
			  if(prod!=null)
			  {
				 
				  int curQuantity = Integer.parseInt(prod.getRemaning_Quantity());
				  curQuantity =curQuantity-1;
				  prod.setRemaning_Quantity(""+curQuantity);
				  addProdService.register(prod);
				  
			  }
			  
	 		  List<Product>prodList = addProdService.getProducts();
	 		  //issueProducts = new IssueProducts();			  
			 // issueProducts.setProdModelNo(prodList.get(0).getModel_No());
			  //issueProducts.setRemaningQnt(prodList.get(0).getRemaning_Quantity());
			  WrapperLists  wrapperList2 = new WrapperLists();
			  wrapperList2.setList(issueList); 		   
			  wrapperList = new WrapperLists();
			  wrapperList.setProdList(prodList);
			  mav.addObject("message","Product Assign !");
			  mav.addObject("prodItemList",wrapperList);
			  mav.addObject("issueItemList",wrapperList2);
		  }
		  else
			  mav.addObject("message","Product is not assign plz do again !");
		    
		  return mav;
	  }
	  
	  @RequestMapping(value = "/deleteProduct", method = RequestMethod.GET)
	  //public ModelAndView deleteProduct(HttpServletRequest request, HttpServletResponse response,String name,@SessionAttribute("user") User user)
	  public ModelAndView deleteProduct(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user)
	  {
		  String name = request.getParameter("prodName");
		  Product prod = new Product();
		  prod.setProd_Name(name);
		  boolean result = addProdService.deleteById(prod);
		  if(result)
		  {
			  List<Product>prodList = addProdService.getProducts();
			  WrapperLists wrapperList = new WrapperLists();
			  wrapperList.setProdList(prodList);
			   
			  ModelAndView mav = new ModelAndView("AddProd.jsp");
			  mav.addObject("Product",new Product());
			  mav.addObject("prodItemList",wrapperList);
			  mav.addObject("message","Product Delete Sucessfully !");
			  return mav;
		  }
		  else
			  return null;
	  }
	  
  
	  
	  @RequestMapping(value = "/returnProduct", method = RequestMethod.POST)
	  public ModelAndView returnProduct(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
	  {
 		  IssueProducts products = issueProdService.getIssueProducts(request.getParameter("empNeName"));
		  ProductReturnHistory returnHistory = new ProductReturnHistory();
		  returnHistory.setEmplCode(products.getEmpCode());
		  returnHistory.setEmplName(products.getEmpName());
		  returnHistory.setIssueDate(products.getIssueDate());
		  returnHistory.setProdName(products.getProdName());
		  returnHistory.setProdModel(products.getProdModelNo());
		  returnHistory.setProdAcceptBy(request.getParameter("prodAccept"));
		  Calendar calender = Calendar.getInstance(); 
		  calender.setTime(new Date());
		  returnHistory.setNeName(calender.getTimeInMillis());
		  returnHistory.setReturnDate(new Date());
		  boolean result = returnProdService.register(returnHistory);
		  List<IssueProducts>issueList = null;
		  ModelAndView mav = null;
		  if(result)
		  {
			 
			 boolean returnVal =  issueProdService.deleteProduct(products);
			 if(returnVal)
			 {
				  Product prod = addProdService.getProducts(products.getProdName());
				  if(prod!=null)
				  {
					 
					  int curQuantity = Integer.parseInt(prod.getRemaning_Quantity());
					  curQuantity =curQuantity+1;
					  prod.setRemaning_Quantity(""+curQuantity);
					  addProdService.register(prod);
					  
				  }
				  SmartChecker.getIstance(issueProdService).deleteIssueObject(""+products.getNeName(), null);
				  if(products.getStatus().equals(ComponentConstantStrings.FAULTY_STATUS))  // this is call from HomePage Page
				  {
					  SmartChecker.getIstance(issueProdService).decrementIssueCounter();
					  faultyUser = SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser");
					  context.setAttribute("faultyUser", faultyUser);
					  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.FAULTY_STATUS+"'";
					  issueList = issueProdService.getIssueProduct(query);
					  mav = new ModelAndView("HomePage.jsp");
					  List<Product>totalProdList = addProdService.getProducts();
					  List<List<Map<Object, Object>>> canvasjsDataList = canvasChartService.getCanvasjsChartData(totalProdList);
					  List<List<Map<Object, Object>>> canvasjsDataList2 = canvasChartService.getCanvasjsChartFaultyData(issueProdService.getIssueProducts());
					  WrapperLists wrapperList = new WrapperLists();
					  wrapperList.setList(issueList);
					  
					  mav.addObject("issuelist",wrapperList);
					  mav.addObject("faultyUser",faultyUser);
					  mav.addObject("dataPointsList",canvasjsDataList);
					  mav.addObject("dataPointsList2",canvasjsDataList2);
				
				  }
				  else					// this is call from IssueProduct  Page
				  {
					  faultyUser = SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser");  
					  context.setAttribute("faultyUser", faultyUser);
					  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.VALID_STATUS+"'";
					  issueList = issueProdService.getIssueProduct(query);
					  List<Product>prodList = addProdService.getProducts();
					  
					  WrapperLists wrapperList = new WrapperLists();
					  WrapperLists  wrapperList2 = new WrapperLists();
					  wrapperList.setList(issueList);
					  wrapperList2.setProdList(prodList);
					  mav = new ModelAndView("IssueProduct.jsp");
					  mav.addObject("message","Product Accepted !");
					  mav.addObject("issueItemList",wrapperList);
					  mav.addObject("prodItemList",wrapperList2);
					
				  }
 
				  return mav;
			 }
		  }
		  
 
		  return null;
	  }
	  
	  

	    @RequestMapping(value = {"/returnHistory"}, method = RequestMethod.GET)
		public ModelAndView returnHistory(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
		 {
			
		
			 List<ProductReturnHistory>returnProdList = returnProdService.getProductsHistory();
			  WrapperLists wrapperList = new WrapperLists();
			  wrapperList.setReturnProdList(returnProdList);
			  context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
			 ModelAndView mav = new ModelAndView("ReturnProdHistory.jsp");
			 mav.addObject("ProdHistoryList",wrapperList);
			 //mav.addObject("userName",user.getUsername());
			 return mav;
		  }
		 
	    @RequestMapping("/logout")
	    public String logoutUser(SessionStatus sessionStatus) 
	    {
	    	//System.out.println("Logout : "+user.getUsername());
	 	    sessionStatus.setComplete(); // to clear session**************
	        return "login.jsp";
	    }
	  

	
	@RequestMapping(value = {"/editIssueDetails"}, method = RequestMethod.POST)
	public ModelAndView editIssueDetails(HttpServletRequest request, HttpServletResponse response,@SessionAttribute("user") User user) 
		{
	 		 ModelAndView mav = new ModelAndView("HomePage.jsp");
	 		try
	 		{
	 
		 		IssueProducts issueProd = new IssueProducts();
		 		issueProd.setNeName(Long.parseLong(request.getParameter("neName")));
		 		issueProd.setEmpName(request.getParameter("emp_Name"));
		 		issueProd.setEmpCode(request.getParameter("empCode"));
		 		issueProd.setEmpMobile(request.getParameter("emp_Mobile"));
		 		Date date1 = dateFormater.parse(request.getParameter("issueDate"));
		 		issueProd.setIssueDate(date1);
		 		issueProd.setProdModelNo(request.getParameter("prodModelNo"));
		 		issueProd.setProdName(request.getParameter("prodName"));
		 		Date date2 = dateFormater.parse(request.getParameter("returnItemDate"));
		 		issueProd.setReturnItemDate(date2);
		 		issueProd.setRemaningQnt(request.getParameter("remaningQnt"));
		 		issueProd.setStatus(ComponentConstantStrings.VALID_STATUS);
		 		  
		 		 
	  	 		if(issueProdService.register(issueProd))
	  	 		{
	  	 			 // SmartChecker.getIstance(issueProdService).deleteIssueObject(request.getParameter("neName"), null);
	  	 			  SmartChecker.getIstance(issueProdService).decrementIssueCounter();
	  	 			  SmartChecker.getIstance(issueProdService).updateIssueObject(""+issueProd.getNeName(), issueProd);
	  	 			  context.setAttribute("faultyUser", SmartChecker.getIstance(issueProdService).getIssueCountertMatrix().get("faultyUser"));
	  	 			  
	  	 			  String query = "select n from com.exicom.model.IssueProducts n where n.status='"+ComponentConstantStrings.FAULTY_STATUS+"'";
					  List<IssueProducts>faultyIssueList = issueProdService.getIssueProduct(query);
					
					  List<List<Map<Object, Object>>> canvasjsDataList = canvasChartService.getCanvasjsChartData(addProdService.getProducts());
					  List<List<Map<Object, Object>>> canvasjsDataList2 = canvasChartService.getCanvasjsChartFaultyData(issueProdService.getIssueProducts());
					  WrapperLists wrapperList = new WrapperLists();
					  wrapperList.setList(faultyIssueList);
					  mav.addObject("issuelist",wrapperList);
					  mav.addObject("dataPointsList",canvasjsDataList);
					  mav.addObject("dataPointsList2",canvasjsDataList2);
	  	 		}
	 		}
	 		catch(Exception e)
	 		{
	 			
	 		}
	 		 return mav;
		 }
	
	public Date parseDate(String Date)
	{
		Date date  = null;
		try {
			date = dateFormater.parse(Date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}
    
	 
	@Override
	public void setServletContext(ServletContext servletContext) {
		this.context = servletContext;
		
		
	}
   
}