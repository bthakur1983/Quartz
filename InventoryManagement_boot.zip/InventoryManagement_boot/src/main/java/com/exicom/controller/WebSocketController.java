package com.exicom.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.Session;

import org.json.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class WebSocketController extends TextWebSocketHandler  
{
	static Set<WebSocketSession>usersSession  = Collections.synchronizedSet(new HashSet<WebSocketSession>());
	String sessionName = null;
	
	@Override
	public void handleTextMessage(WebSocketSession wsSession, TextMessage message)throws Exception
	{
		try
		{
			System.out.println("websocket called..........");
			usersSession.add(wsSession);	
	 
			String payload = message.getPayload();
			JSONObject jsonObject = new JSONObject(payload);
			sessionName = (String)wsSession.getAttributes().get("userName");
			if(sessionName == null)
			{
				wsSession.getAttributes().put("userName", jsonObject.get("userName"));
				usersSession.add(wsSession);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
//		String payload = message.getPayload();
//		JSONObject jsonObject = new JSONObject(payload);
//		session.sendMessage(new TextMessage("Hi " + jsonObject.get("user") + " how may we help you?"));
	}

	
	public static void updateDashBoard(HashMap<String, String>dataMap)throws IOException
	{
		
		Iterator<WebSocketSession> itr = usersSession.iterator();		 
		while(itr.hasNext())
		 {
			WebSocketSession sess = (WebSocketSession)itr.next();
		    try
		    {
			    
				    JSONObject obj = new JSONObject();
				    obj.put("dataMap", dataMap);
				    sess.sendMessage(new TextMessage(obj.toString()));
				    
				   // sess.sendMessage(obj);
				    //sess.getBasicRemote().sendText(obj.toString());
				   
			    
		   
		    }
		    catch(Exception e)
		    {
		    	System.out.println("websocket Closed..........");
		    }
		 }
	}

}
