package com.exicom;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;

import com.exicom.controller.WebSocketController;

import com.exicom.dao.IssueProductDao;
import com.exicom.dao.IssueProductsImplement;
import com.exicom.model.IssueProducts;
import com.exicom.util.ComponentConstantStrings;
 

public class SmartChecker  
{
	
	 public IssueProductDao issueProdService;
	 SimpleDateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	private static SmartChecker _instance = null;
	public List<IssueProducts>issueList = null;
	public Hashtable<String, IssueProducts> issueMap = null;
	public Hashtable<String, Integer> issueCounterMap = new Hashtable<>();
	static Date curDate = null;
	Timer timer = null;
	static Shaper shaper = null;
	public volatile int counter=0;
	public static SmartChecker getIstance(IssueProductDao issueProdService)
	{
		if(_instance == null)
		{
			
			_instance = new SmartChecker();
			_instance.issueProdService = issueProdService;
			return _instance; 
		}
		else
			return _instance;
	}
	
	private SmartChecker()
	{
	 
 		issueMap = new Hashtable<>();
 		if(shaper == null) {
			shaper = new Shaper();
		}
//		lastIssueTimeMap = new Hashtable<String, Object>();
//		issueList = new IssueProductsImplement().getIssueProducts();
//		if(issueList!=null || issueList.size()>0)
//		{
//			for(int i=0;i<issueList.size();i++)
//			{
//				getRequestMatrix().put(""+issueList.get(i).getNeName(), issueList.get(i));
//				
//				
//			}
//			
//			 
//		}
		
		TimerTask timerTask = new Shaper();
		Timer timer = new Timer(true);
		timer.scheduleAtFixedRate(timerTask, 0, 30*1000);
		System.out.println("timer started...");
		
 		 
	}
	
	public void addIssueCounter(String faultyUser,Integer counter)
	{
		 
			getIssueCountertMatrix().put(faultyUser, counter);
		 
	}
	
	public void addNewIssueObject(String neName,IssueProducts issueProd)
	{
		if(!getRequestMatrix().containsKey(neName))
		{
			getRequestMatrix().put(neName, issueProd);
		}
	}
	public void updateIssueObject(String neName,IssueProducts issueProd)
	{
		 
			getRequestMatrix().put(neName, issueProd);
		 
	}
	
	public void deleteIssueObject(String neName,IssueProducts issueProd)
	{
		if(getRequestMatrix().containsKey(neName))
		{
			getRequestMatrix().remove(neName);
	 			 
		}
	}
	
	public void decrementIssueCounter()
	{
		if(getIssueCountertMatrix().get("faultyUser")>0)
		{
			getIssueCountertMatrix().put("faultyUser", getIssueCountertMatrix().get("faultyUser")-1);
		}
	}
	
	public  Hashtable<String, IssueProducts> getRequestMatrix()
	{
		return issueMap;
	}
	public  Hashtable<String, Integer> getIssueCountertMatrix()
	{
		return issueCounterMap;
	}
	 
	 
	 

 

class Shaper extends TimerTask
{
	
	boolean flag = false;
	public Hashtable<String, Object> lastIssueTimeMap  = null;
	
	public Shaper()
	{
		
	}
	@Override
	public void run() {
		 
		 
			try
			{
				Set<String> requestQueueNeNames = new LinkedHashSet<>(getRequestMatrix().keySet());
				for(String neName:requestQueueNeNames)
				{
				 IssueProducts prod = (IssueProducts)getRequestMatrix().get(neName);
				 curDate = new Date();
				 if(curDate.after(prod.getReturnItemDate()) && prod.getStatus().equals(ComponentConstantStrings.VALID_STATUS))
				 {
					 prod.setStatus(ComponentConstantStrings.FAULTY_STATUS);
					 if(updateFaultyStatusIssueProduct(prod))
					 {
						
						 HashMap<String, String> map =new HashMap<>();
						 counter = getIssueCountertMatrix().get("faultyUser")+1;
						 map.put("counter", ""+counter);
						 getIssueCountertMatrix().put("faultyUser", counter);
						 int validUser = getRequestMatrix().size() -getIssueCountertMatrix().get("faultyUser");
						 map.put("faultyUser", ""+counter);
						 map.put("validUser", ""+validUser);
						 map.put("neName", ""+prod.getNeName());
						 map.put("empName", prod.getEmpName());
						 map.put("empCode", prod.getEmpCode());
						 map.put("empMobile", prod.getEmpMobile());
						 map.put("prodName", prod.getProdName());
						 map.put("prodModel", prod.getProdModelNo());
						 map.put("remaningQnt", prod.getRemaningQnt());
						 map.put("issueDate", dateFormater.format(prod.getIssueDate()));
						 map.put("retDate",  dateFormater.format(prod.getReturnItemDate()));
						 WebSocketController.updateDashBoard(map);
				 	}
				 }
				
				}
				
			}
			catch(Exception e)
			{
				
			}
		 
	}
	
	public boolean updateFaultyStatusIssueProduct(IssueProducts issueProd)
	{
		boolean result = false;
		try
		{
			result = issueProdService.register(issueProd);
		}
		catch(Exception e)
		{
			
		}
		return result;
	}
//	public Date parseDate(String Date)
//	{
//		Date date  = null;
//		try {
//			date = dateFormater.parse(Date);
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return date;
//	}
    
	 
	 
} 
	
}
