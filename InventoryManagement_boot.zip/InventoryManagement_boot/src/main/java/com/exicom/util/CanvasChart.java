package com.exicom.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.exicom.SmartChecker;
import com.exicom.model.IssueProducts;
import com.exicom.model.Product;

public class CanvasChart 
{
	
	static Map<Object,Object> map = null;
	static List<List<Map<Object,Object>>> list = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints1 = new ArrayList<Map<Object,Object>>();
	
	static Map<Object,Object> map2 = null;
	static List<List<Map<Object,Object>>> list2 = new ArrayList<>();
	static List<Map<Object,Object>> dataPoints2 = new ArrayList<Map<Object,Object>>();
	
	  
	 public static void clearList()
	 {
		 if(list.size()>0)
			  list.clear();
		  if(dataPoints1.size()>0)
			  dataPoints1.clear();
		 
	 }
	 public static void clearList2()
	 {
		 
		  if(list2.size()>0)
			  list2.clear();
		  if(dataPoints2.size()>0)
			  dataPoints2.clear();
	 }
	public static List<List<Map<Object, Object>>> getCanvasjsDataList(List<Product>totalProdList)
	{
		clearList();
		for(int i=0;i<totalProdList.size();i++)
		{
		map = new HashMap<Object,Object>();
		map.put("label", totalProdList.get(i).getProd_Name());
		map.put("y",  totalProdList.get(i).getRemaning_Quantity());
		dataPoints1.add(map);
		
		}
		list.add(dataPoints1);
		return list;
	}
	
	public static List<List<Map<Object, Object>>> getCanvasjsChartFaultyData(List<IssueProducts>totalFaultyList)
	{
		clearList2();
		if(totalFaultyList.size()>0)
		{
			 int faultyUser = SmartChecker.getIstance(null).getIssueCountertMatrix().get("faultyUser");
			 int validUser = totalFaultyList.size() - faultyUser;
			 
				 
			 if(faultyUser>0)
			 {
				 	map2 = new HashMap<Object,Object>();
					map2.put("name", "Faulty Employee");
					map2.put("y",  SmartChecker.getIstance(null).getIssueCountertMatrix().get("faultyUser"));
					dataPoints2.add(map2);	
			 }
			 if(validUser>0)
			 {
					map2 = new HashMap<Object,Object>();
					map2.put("name", "Valid Employee");
					map2.put("y",  validUser);
					dataPoints2.add(map2);
			 }
				 
			  
			 
		 }
 
 		list2.add(dataPoints2);
 		return list2;
	}
	
	
	
 

}
