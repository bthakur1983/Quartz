package com.exicom.util;

import java.util.ArrayList;
import java.util.List;

import com.exicom.model.IssueProducts;
import com.exicom.model.Product;
import com.exicom.model.ProductReturnHistory;
import com.exicom.model.User;

 


public class WrapperLists
{
	public List<IssueProducts> list;
	public List<Product> prodList;
	public List<ProductReturnHistory>returnProdList;
	public List<User> userList;
	 
	public List<ProductReturnHistory> getReturnProdList() {
			return returnProdList;
		}

	public void setReturnProdList(List<ProductReturnHistory> returnProdList) {
			this.returnProdList = returnProdList;
		}
	public List<IssueProducts> getList() {
		return list;
	}

	public void setList(List<IssueProducts> list) {
		this.list = list;
	}

	public List<Product> getProdList() {
		return prodList;
	}

	public void setProdList(List<Product> prodList) {
		this.prodList = prodList;
	}

	public List<User> getUserList() {
		return userList;
	}

	public void setUserList(List<User> userList) {
		this.userList = userList;
	}

	 
	 

	 


}
