package com.exicom.util;

import java.util.Hashtable;

 

public class ComponentConstantStrings
{
	public static final String VALID_STATUS 						= "valid";
	public static final String FAULTY_STATUS						="faulty";
	public static final String ADMIN_ROLE							="administrator";
	
	 
}