package com.exicom.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.IssueProducts;
import com.exicom.model.Product;
import com.exicom.util.CanvasChart;
 
@Repository
//@Service
//@Transactional
public class CanvasChartDaoImpl implements CanvasChartDao {

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsChartData( List<Product>totalProdList) {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsDataList(totalProdList);
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsChartFaultyData(List<IssueProducts> totalFaultyList) {
		// TODO Auto-generated method stub
		return CanvasChart.getCanvasjsChartFaultyData(totalFaultyList);
		 
	}

}
