package com.exicom.dao;

import java.util.List;

import com.exicom.model.Product;

 

public interface AddProductDao 
{
	public boolean register(Product prod);
	public List<Product> getProducts();
	public boolean deleteById(Product prod);
	public Product getProducts(String neName);
	public void refreshCache();

}
