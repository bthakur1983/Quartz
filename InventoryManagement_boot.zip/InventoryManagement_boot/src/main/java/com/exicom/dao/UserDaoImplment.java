package com.exicom.dao;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.Product;
import com.exicom.model.User;
import com.exicom.util.HibernateUtil;
//import com.googlecode.ehcache.annotations.Cacheable;

//@Service
//@Transactional
@Repository
public class UserDaoImplment implements UserDao
{

	@Autowired
    private SessionFactory sessionFactory;
	
	@Autowired
    private HibernateUtil hibernateUtil;

	@Override
	public Boolean register(User user)
	{
		boolean result = false;
		try
		{
			hibernateUtil.update(user);		 
			result = true;
		}
		catch(Exception e)
		{
			
		}
		return result;
		 
		 
	}
	
	@Override
	//@Cacheable(cacheName="com.exicom.model.User")
	public List<User> getDataFromDB(String sqlQuery)throws RemoteException
	{ 
	 
		List<User> retVal = new ArrayList<>();
		 
		try {
			 
		 
			 retVal = hibernateUtil.fetchAll(sqlQuery);
			
 			 
			 
		} catch (Exception e) {
			//Log.getLog().error("jpa.Database getDataFromDB : sqlQuery "+e.getMessage() );
		}
		return retVal;
	}

	@Override
	public List<User> getUsers() {
		 
		List<User> retVal = new ArrayList<>();
		try
		{
			 			 
			retVal= hibernateUtil.fetchAll(User.class);
			 
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return retVal;
	}
	 

}
