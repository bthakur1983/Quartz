package com.exicom.dao;

 
import java.rmi.RemoteException;
import java.util.List;

import com.exicom.model.Product;
import com.exicom.model.User;

 
public interface UserDao {

	  Boolean register(User user);
	  public List<User> getUsers();
	  public List<User> getDataFromDB(String sqlQuery)throws RemoteException;
	  
	  
}
