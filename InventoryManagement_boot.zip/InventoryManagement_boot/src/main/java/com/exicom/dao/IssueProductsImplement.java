package com.exicom.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.IssueProducts;
import com.exicom.util.HibernateUtil;



//@Service
//@Transactional
@Repository
public class IssueProductsImplement implements IssueProductDao {

	@Autowired
    private HibernateUtil hibernateUtil;
	 
	
 	@Override
	public boolean register(IssueProducts product)
	{
		boolean result = false;
		try
		{
			 
			hibernateUtil.update(product);
			result = true;
		}
		catch(Exception e)
		{
			
		}
		return result;
	}

	@Override 
	public List<IssueProducts> getIssueProducts()
	{
	
		List<IssueProducts> retVal = new ArrayList<>();
		try
		{
			 
			 
			retVal= hibernateUtil.fetchAll(IssueProducts.class);
			return retVal;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public IssueProducts getIssueProducts(String neName)
	{
		 
		try
		{
			long tempneName = Long.parseLong(neName);
		 
			 
			IssueProducts prod = hibernateUtil.fetchById(tempneName, IssueProducts.class);
			return prod;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public boolean deleteProduct(IssueProducts prod) {
		// TODO Auto-generated method stub
		boolean retVal = false;
		 
		 try
			{
				 
			 	hibernateUtil.delete(prod);
				 retVal = true;
				 return retVal;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		return retVal;
	}

	@Override
	public List<IssueProducts> getIssueProduct(String query) {
		 
		List<IssueProducts> retVal = null;
		 
		try {
			 
		 
			 retVal =  (List<IssueProducts>)hibernateUtil.fetchAll(query);
			
 			 
			 
		} catch (Exception e) {
			//Log.getLog().error("jpa.Database getDataFromDB : sqlQuery "+e.getMessage() );
		}
		return retVal;
	}

	@Override
	public boolean update(String query,Map<String, String>map) {
 
		return hibernateUtil.updateData(query,map);
	}

}
