package com.exicom.dao;

import java.util.List;

import com.exicom.model.ProductReturnHistory;

 
 

public interface ReturnProductHistoryDao
{
	public boolean register(ProductReturnHistory productHistory);
	public List<ProductReturnHistory> getProductsHistory();

}
