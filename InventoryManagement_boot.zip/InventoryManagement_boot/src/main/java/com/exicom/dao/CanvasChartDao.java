package com.exicom.dao;

import java.util.List;
import java.util.Map;

import com.exicom.model.IssueProducts;
import com.exicom.model.Product;



public interface CanvasChartDao
{
	List<List<Map<Object, Object>>> getCanvasjsChartData(List<Product>totalProdList);
	List<List<Map<Object, Object>>> getCanvasjsChartFaultyData(List<IssueProducts>totalFaultyList);

}
