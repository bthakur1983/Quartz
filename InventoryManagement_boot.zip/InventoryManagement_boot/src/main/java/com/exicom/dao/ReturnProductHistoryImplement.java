package com.exicom.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.ProductReturnHistory;
import com.exicom.util.HibernateUtil;
//import com.googlecode.ehcache.annotations.Cacheable;

//@Service
//@Transactional
@Repository
public class ReturnProductHistoryImplement implements ReturnProductHistoryDao 
{
	
	@Autowired
    private HibernateUtil hibernateUtil;
	
	
	@Override
	public boolean register(ProductReturnHistory productHistory) {
		// TODO Auto-generated method stub
		boolean result = false;
		try
		{
			 
			hibernateUtil.update(productHistory);
			result = true;
		}
		catch(Exception e)
		{
			
		}
		return result;
	}

	@Override
	//@Cacheable(cacheName="com.exicom.model.ProductReturnHistory")
	public List<ProductReturnHistory> getProductsHistory() {
		 
		List<ProductReturnHistory> retVal = new ArrayList<>();
		try
		{
			 
			 
			retVal= hibernateUtil.fetchAll(ProductReturnHistory.class);
			return retVal;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

}
