package com.exicom.dao;

import com.exicom.model.Employee;

public interface EmployeeDao
{
	public void createEmployee(Employee emp);

}
