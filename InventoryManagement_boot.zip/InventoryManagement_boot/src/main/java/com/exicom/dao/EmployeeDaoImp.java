package com.exicom.dao;







import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.Employee;
import com.exicom.util.HibernateUtil;
 

@Repository
//@Service
//@Transactional
public class EmployeeDaoImp implements EmployeeDao {

	@Autowired
	//private SessionFactory sessionFactory;
	private HibernateUtil hibernateUtil;
	
	public void createEmployee(Employee emp)
	{
		 
		 
		try
		{
			 //Session session = sessionFactory.getCurrentSession();
			 //session.saveOrUpdate(emp);
			hibernateUtil.create(emp);
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
