package com.exicom.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.exicom.model.Product;
import com.exicom.util.HibernateUtil;
 
//@Transactional
//@Service
@Repository
@CacheConfig(cacheNames= {"addProduct"})
public class AddProductDaoImplement implements AddProductDao {

	@Autowired
    private HibernateUtil hibernateUtil;
	
	@Override
	//@CachePut(value="addProduct",key="#product.prod_Name")
	@CacheEvict(value="addProduct",allEntries=true)
	public boolean register(Product product) 
	{
		boolean result = false;
		try
		{
			 
			hibernateUtil.update(product);
			
			result = true;
		}
		catch(Exception e)
		{
			
		}
		return result;
	}

	@Override 
	@Cacheable
	public List<Product> getProducts() {
		List<Product> retVal = new ArrayList<>();
		try
		{
			 
			 
			retVal= hibernateUtil.fetchAll(Product.class);
			return retVal;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	@CacheEvict(value="addProduct",allEntries=true)
	public boolean deleteById(Product prod)
	{
			boolean retVal = false;
 
		 try
			{
				  
			 	hibernateUtil.delete(prod);
				 retVal = true;
				 return retVal;
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		return retVal;
	}

	@Override 
	@Cacheable
	public Product getProducts(String neName) {
		// TODO Auto-generated method stub
		try
		{
			 
			
			Product prod = hibernateUtil.fetchById(neName, Product.class);
			return prod;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	@CacheEvict(allEntries = true)
	public void refreshCache()
	{
		
	}


}
