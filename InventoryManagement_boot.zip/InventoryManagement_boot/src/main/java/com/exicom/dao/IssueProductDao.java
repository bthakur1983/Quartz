package com.exicom.dao;

import java.util.List;
import java.util.Map;

import com.exicom.model.IssueProducts;

 

public interface IssueProductDao
{
	public boolean register(IssueProducts product);
	public List<IssueProducts> getIssueProducts();
	public List<IssueProducts> getIssueProduct(String query);
	public IssueProducts getIssueProducts(String neName);
	public boolean deleteProduct(IssueProducts prod);
	public boolean update(String query,Map<String, String>map);

}
