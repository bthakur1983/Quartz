import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;


public class OpsManager 
{
	public static Scheduler scheduler = null;
	public static Scheduler getScheduleInstanse()
	{
		if(scheduler ==null)
		{
			try
			{
			SchedulerFactory sf = new StdSchedulerFactory();
			scheduler = sf.getScheduler();
			scheduler.start();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return scheduler;
	}

}
