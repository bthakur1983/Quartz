import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Trigger;

public class Main 
{
	Map<String, Object> jobMap = new HashMap<>();
	String triggerName="myTrigger";
	String triggerGroup ="myGroup";
	
	public void assignTask(ClientIMO clientIMo)
	{

		try
		{
		Date executeDate = new Date();
		Calendar cal = Calendar.getInstance();
	 
		cal.setTime(executeDate);
		cal.add(Calendar.MINUTE, 1);
		
		DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy hh:mm:ss");
		String triggerTime = dateFormat.format(cal.getTime());
		jobMap = Javautil.addJob(TaskExecutor.class,clientIMo.getClientName(),triggerName,triggerGroup,clientIMo,triggerTime);
		OpsManager.getScheduleInstanse().scheduleJob((JobDetail)jobMap.get("job"),(Trigger)jobMap.get("trigger"));
		//OpsManager.getScheduleInstanse().scheduleJob((JobDetail)jobMap.get(clientIMo.getClientName()), (CronTrigger)jobMap.get(clientIMo.getClientAddress()));
		Thread.sleep(20000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String ar[])
	{
		ClientIMO clientIMo = new ClientIMO();
		clientIMo.setClientName("bhupendra");
		clientIMo.setClientAddress("delhi");

		Main obj = new Main();
		obj.assignTask(clientIMo);
		
	}

}
