import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.JobDetailImpl;

public class Javautil 
{
	public static Map<String, Object>addJob(Class className,String jobName,String triggerName,String triggerGroup,ClientIMO clientIMO,String triggerDate)
	{
	
		Map<String ,Object> jobTriggerMap = new HashMap<>();
		try
		{
		
			JobDetail jd = JobBuilder.newJob(className).withIdentity(jobName, triggerGroup).build();
			jd.getJobDataMap().put("clientIMO", clientIMO);
			Trigger trigger = TriggerBuilder.newTrigger().withIdentity("crontrigger1", triggerGroup).withSchedule(CronScheduleBuilder.cronSchedule("0/7 * * * * ?")).build();
			jobTriggerMap.put("job", jd);
			jobTriggerMap.put("trigger", trigger);
		/*JobDetail jd1 = new JobDetailImpl();
		((JobDetailImpl)jd1).setName(jobName);
		((JobDetailImpl)jd1).setJobClass(className);
		jobTriggerMap.put(jobName, jd1);
		jd1.getJobDataMap().put("clientMO", clientIMO);
		
		CronTrigger cron=TriggerBuilder.newTrigger().withIdentity(triggerName, triggerGroup).withSchedule(CronScheduleBuilder.cronSchedule("0/7 * * * * ?")).build();
		jobTriggerMap.put(triggerName, cron);*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
//		jobTriggerMap.put(jobName, jd1);
//		jd1.getJobDataMap();
//		TriggerBuilder<Trigger>
//		CronTrigger cron=TriggerBuilder;
		
		return jobTriggerMap;
	}

}
