
public class ClientIMO 
{
	private String clientName=null;
	private String clientAddress=null;
	public ClientIMO() {
		// TODO Auto-generated constructor stub
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientAddress() {
		return clientAddress;
	}
	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	
	
}
