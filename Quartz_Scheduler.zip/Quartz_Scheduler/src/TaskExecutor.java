import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class TaskExecutor implements Job {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException 
	{
		 System.out.println("trigger execute........");
		 ClientIMO clientIMO =(ClientIMO) arg0.getJobDetail().getJobDataMap().get("clientIMO");
		System.out.println("Name is : "+clientIMO.getClientName());
	}
	

}
